console.log('FS SHOPPING carregado');
